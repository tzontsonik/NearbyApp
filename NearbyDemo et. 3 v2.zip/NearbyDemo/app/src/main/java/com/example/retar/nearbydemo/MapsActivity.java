package com.example.retar.nearbydemo;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String TAG = "MapsActivity";
    private static final String FINE_LOCATION = android.Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COARSE_LOCATION = android.Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 15;
    public String s;
    private GoogleMap mMap;
    private Boolean mLocationPermissionsGranted = false;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    /////////////////////////////////
    //DATABASE
    ////////////////////////////////
    // [START declare_database_ref]
    private DatabaseReference mDatabase;
    // [END declare_database_ref]


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        Intent intent = getIntent();

        Bundle bundle = intent.getExtras();
        s = bundle.getString("user");

        getLocationPermission();

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        Toast.makeText(this, "Map is Ready", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onMapReady: map is ready");
        // Add a marker in Sydney and move the camera
        // LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        if (mLocationPermissionsGranted) {
            getDeviceLocation();
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            mMap.setMyLocationEnabled(true);
        }

    }

    private void getDeviceLocation(){
        Log.d(TAG, "getDeviceLocation: ready");

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        try{
            if(mLocationPermissionsGranted){
                Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                      if(task.isSuccessful()) {
                          Log.d(TAG, "getDeviceLocation: found location");
                          Location currentLocation = (Location) task.getResult();
                          moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), DEFAULT_ZOOM);
                          int latitude = (int) currentLocation.getLatitude();
                          int longitude = (int) currentLocation.getLongitude();
                         // String strLatitude = Integer.toString(latitude);
                          //String strLongitude = Integer.toString(longitude);

                          String strLongitude = currentLocation.convert(currentLocation.getLongitude(), currentLocation.FORMAT_DEGREES);
                          String strLatitude = currentLocation.convert(currentLocation.getLatitude(), currentLocation.FORMAT_DEGREES);
                       //   Toast.makeText(MapsActivity.this, currentLocation.getLatitude(), Toast.LENGTH_SHORT).show();
                          Toast.makeText(MapsActivity.this, strLatitude, Toast.LENGTH_SHORT).show();
                          Toast.makeText(MapsActivity.this, strLongitude, Toast.LENGTH_SHORT).show();
                          /////////////////////////////////
                          //DATABASE
                          ////////////////////////////////
                          // [START initialize_database_ref]
                          mDatabase = FirebaseDatabase.getInstance().getReference();
                          // [END initialize_database_ref]
                         // mDatabase.child(s).setValue(strLatitude + " " + strLongitude);

                      }else{
                          Log.d(TAG, "getDeviceLocation: did not find location");
                          Toast.makeText(MapsActivity.this, "Location unavailable", Toast.LENGTH_SHORT).show();

                      }
                    }
                });
            }

        }catch(SecurityException e){
            Log.d(TAG, "getDeviceLocation: SecurityException" + e.getMessage());
        }
    }

    private void moveCamera(LatLng latLng, float zoom){
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));

    }
    private void initMap(){
        Log.d(TAG, "initMap: init map is ready");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(MapsActivity.this);
    }

    private void getLocationPermission(){
        Log.d(TAG, "getLocationPermission: permission map is ready");
        String[] permissions ={android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(), FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(), COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionsGranted = true;
                initMap();
            }else{
                ActivityCompat.requestPermissions(this, permissions,LOCATION_PERMISSION_REQUEST_CODE );
            }

        }else{
            ActivityCompat.requestPermissions(this, permissions,LOCATION_PERMISSION_REQUEST_CODE );
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsRestul: called");
        mLocationPermissionsGranted =false;

        switch(requestCode){
            case LOCATION_PERMISSION_REQUEST_CODE:{
                if(grantResults.length > 0 )
                    for(int i = 0; i < grantResults.length; i++)
                        if(grantResults[i] == PackageManager.PERMISSION_GRANTED){
                            Log.d(TAG, "onRequestPermissionsRestul: failed");
                            mLocationPermissionsGranted = false;
                            return;
                        }
                    mLocationPermissionsGranted = true;
                Log.d(TAG, "onRequestPermissionsRestul: success");
                //initialize map
                initMap();
            }
        }
    }
}
