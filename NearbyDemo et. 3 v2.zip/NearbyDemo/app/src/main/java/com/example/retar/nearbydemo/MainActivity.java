package com.example.retar.nearbydemo;


import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;

import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnCompleteListener;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Arrays;
import java.util.List;



import static android.widget.Toast.LENGTH_LONG;


public class MainActivity extends AppCompatActivity {

    //check google version
    private static final String TAG = "MainActivity";
    private static final int ERROR_DIALOG_REQUEST = 9001;
    public static CallbackManager callbackManager;

    /**
     * Varibila care retine numele utilizatorului
     */
    public String username;


    /**
     * Permisiuni solocitate de autentificarea cu Facebook
     */
    List<String> permissionNeeds = Arrays.asList("publish_actions");


    /**
     * Variabile utilizate de autentificarea Firebase
     */
    private FirebaseAuth mAuth;
    private TextView mStatusTextView;
    private TextView mDetailTextView;


    /**
     * Referinta baza de date
     */
    private DatabaseReference mDatabase;
    private FirebaseDatabase mDatabase2;



    /**
     * Variabila reprezentand starea de autentificare
     */
    private boolean isLoggedIn;




    private boolean mAlreadyStartedService = false;
    private FusedLocationProviderClient mFusedLocationClient;


    // location
    Location mCurrentLocation;
    LocationCallback mLocationCallback;
    LocationRequest mLocationRequest;




    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Facebook
        FacebookSdk.sdkInitialize(this.getApplicationContext());
        callbackManager = CallbackManager.Factory.create();

        // Initializare Firebase
        mAuth = FirebaseAuth.getInstance();

        // Content
        setContentView(R.layout.activity_main);

        // Views
        mStatusTextView = findViewById(R.id.status);
        mDetailTextView = findViewById(R.id.detail);




        // Permisiune email
        LoginManager.getInstance().logInWithPublishPermissions(this, permissionNeeds);
        LoginManager.getInstance().logInWithReadPermissions(
                this,
                Arrays.asList("email"));

        //facebook login manager
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // App code
                        handleFacebookAccessToken(loginResult.getAccessToken());
                        // locatie

                    }

                    @Override
                    public void onCancel() {
                        // App code
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // App code
                    }
                });


        // Referinta baza de date
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Obtinere username
        username = mAuth.getCurrentUser().getDisplayName();


        // location
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            // Logic to handle location object
                            String strLongitude = location.convert(location.getLongitude(), location.FORMAT_DEGREES);
                            String strLatitude = location.convert(location.getLatitude(), location.FORMAT_DEGREES);
                            //   Toast.makeText(MapsActivity.this, currentLocation.getLatitude(), Toast.LENGTH_SHORT).show();
                            Toast.makeText(MainActivity.this, strLatitude, Toast.LENGTH_SHORT).show();
                            Toast.makeText(MainActivity.this, strLongitude, Toast.LENGTH_SHORT).show();
                        }
                    }
                });


        createLocationRequest();
        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    // Update UI with location data
                    // ...
                    String strLongitude = location.convert(location.getLongitude(), location.FORMAT_DEGREES);
                    String strLatitude = location.convert(location.getLatitude(), location.FORMAT_DEGREES);
                    //   Toast.makeText(MapsActivity.this, currentLocation.getLatitude(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, strLatitude, Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, strLongitude, Toast.LENGTH_SHORT).show();
                    mDatabase.child("users").child(username).setValue(strLatitude + " " + strLongitude);


                    mDatabase2 = FirebaseDatabase.getInstance();
                    DatabaseReference ref = mDatabase2.getReference("users");

                    String name;

                    ref.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                           //dataSnapshot.getValue(name);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            System.out.println("The read failed: " + databaseError.getCode());
                        }
                    });
                }
            };
        };


    } // end of onCreate(Bundle savedInstanceState)



    protected void createLocationRequest() {
         mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);

        LocationSettingsRequest.Builder builder2 = new LocationSettingsRequest.Builder();

// ...

        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder2.build());

        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                // All location settings are satisfied. The client can initialize
                // location requests here.
                // ...
            }
        });

        /*
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    // Location settings are not satisfied, but this can be fixed
                    // by showing the user a dialog.
                    try {
                        // Show the dialog by calling startResolutionForResult(),
                        // and check the result in onActivityResult().
                        ResolvableApiException resolvable = (ResolvableApiException) e;
                        resolvable.startResolutionForResult(MainActivity.this,
                                REQUEST_CHECK_SETTINGS);
                    } catch (IntentSender.SendIntentException sendEx) {
                        // Ignore the error.
                    }
                }
            }
        }); */
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (1 == 1) {
            startLocationUpdates();
        }
    }

    @SuppressLint("MissingPermission")
    private void startLocationUpdates() {
        mFusedLocationClient.requestLocationUpdates(mLocationRequest,
                mLocationCallback,
                null /* Looper */);
    }

    @Override
    public void onStart() {
        super.onStart();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        mAuth.getCurrentUser().getEmail();
        updateUI(currentUser);
    } // end of onStart()

    private void updateUI(FirebaseUser user) {
        if (user != null) {
            mStatusTextView.setText(getString(R.string.facebook_status_fmt, user.getDisplayName()));
        } else {
            mStatusTextView.setText(R.string.signed_out);

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

    }


    private void handleFacebookAccessToken(AccessToken token) {
        Log.d(TAG, "handleFacebookAccessToken:" + token);

        final AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            Toast.makeText(MainActivity.this, "Authentication success.",
                                    Toast.LENGTH_SHORT).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            user.getProviderId();

                            updateUI(user);


                            // variabila isLoggedIn arata daca utilizatorul este autentificat sau nu
                            AccessToken accessToken = AccessToken.getCurrentAccessToken();
                            isLoggedIn = accessToken != null && !accessToken.isExpired();

                            // daca utilizatorul este autentificat poate accesa functiile aplicatiei
                            if (isServicesOK() && isLoggedIn) {
                                initMap();
                                initChat();
                                initLogout();


                            }


                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            Toast.makeText(MainActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            updateUI(null);
                        }
                    }
                });
    } // end of handleFacebookAccessToken(AccessToken token)


    //GOOGLE VERSION
    public boolean isServicesOK() {
        Log.d(TAG, "isServicesOK: checking google services version");

        int available = GoogleApiAvailability.getInstance().
                isGooglePlayServicesAvailable(MainActivity.this);

        if (available == ConnectionResult.SUCCESS) {
            //everything is fine and the user can make map requests
            Log.d(TAG, "isServicesOK: gplay services is working");
            return true;
        } else if (GoogleApiAvailability.getInstance().isUserResolvableError(available)) {
            // an error occured but we can resolve it
            Log.d(TAG, "isServicesOK: error occured but we can fix it ");
            Dialog dialog = GoogleApiAvailability.getInstance().
                    getErrorDialog(MainActivity.this, available, ERROR_DIALOG_REQUEST);
            dialog.show();
        } else {
            Toast.makeText(this, "we can't connect", Toast.LENGTH_SHORT).show();
        }
        return false;
    } // end of isServicesOK()


    // Functie intializare harta
    private void initMap() {

        // daca utilizatorul este autentificat poate accesa Google Maps
        if (isLoggedIn == true) {
            Button btnMap = (Button) findViewById(R.id.btnMap);
            btnMap.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    if (isLoggedIn == true) {
                        Intent intent = new Intent(MainActivity.this,
                                MapsActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("user", username);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    } else {
                        // daca utilizatorul nu este autentificat se afiseaza un mesaj
                        Toast.makeText(MainActivity.this, "Please log in with Facebook",
                                Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
    } // end of initMap()

    // Functie initializare Chat
    private void initChat() {

        if (isLoggedIn == true) {
            Button btnChat = (Button) findViewById(R.id.chatBtn);
            btnChat.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isLoggedIn == true) {
                        Intent intent = new Intent(MainActivity.this, ChatActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Please log in with Facebook",
                                Toast.LENGTH_SHORT).show();

                    }

                }
            });
        }
    } // end of initChat()

    // Functie logout
    private void initLogout() {
        Button btnLogOut = findViewById(R.id.login_button);
        btnLogOut.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (isLoggedIn == true) {
                    isLoggedIn = false;
                }
            }
        });
    } // end of initLogout()





}





