package com.example.retar.nearbydemo;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static java.time.format.DateTimeFormatter.ofPattern;

/**
 * Created by retar on 24-Apr-18.
 */

@RequiresApi(api = Build.VERSION_CODES.O)
public class ChatMessage {
    private String messageText;
    private String messageUser;
    private String messageTime;

    private static final DateTimeFormatter dtf = ofPattern("yyyy/MM/dd HH:mm:ss");

    public ChatMessage(String messageText, String messageUser) {
        this.messageText = messageText;
        this.messageUser = messageUser;

        // Initialize to current time
        //messageTime = new Date().getTime();

        LocalDateTime now = LocalDateTime.now();
        //System.out.println(dtf.format(now));
        messageTime = dtf.format(now);
    }

    public ChatMessage(){

    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getMessageUser() {
        return messageUser;
    }

    public void setMessageUser(String messageUser) {
        this.messageUser = messageUser;
    }

    public String getMessageTime() {
        return messageTime;
    }

    public void setMessageTime(long messageTime) {
        //this.messageTime = messageTime;
    }
}
